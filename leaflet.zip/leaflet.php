<?php
// Copyright (c) 2013-2016 Datenstrom, http://datenstrom.se
// This file may be used and distributed under the terms of the public license.

// Leaflet plugin by nibreh - http://leafletjs.com/
class YellowLeaflet
{
	const VERSION = "0.6.1";
	var $yellow;			//access to API

	// Handle initialisation
	function onLoad($yellow)
	{
		$this->yellow = $yellow;
		$this->yellow->config->setDefault("LeafletJs", "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/");
		$this->yellow->config->setDefault("LeafletCss", "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/");
	}

	// Handle page content parsing of custom block
	function onParseContentBlock($page, $name, $text, $shortcut)
	{
		$output = null;
		if($name=="leaflet" && $shortcut)
		{
			list($longitude, $latitude,$height, $zoom ) = $this->yellow->toolbox->getTextArgs($text);
			if(empty($longitude)) $longitude = "48.000"; // Paris/London by default
			if(empty($latitude)) $latitude = "2.000";
			if(empty($height)) $height = "500px";
			if(empty($zoom)) $zoom = "5";
			$output = "<div id=\"leaflet\" style=\"height:".htmlspecialchars($height)."\">\n";
			$output .="</div>\n";
			$output .= "<script type=\"text/javascript\">\n";
			$output .= "var map = L.map('leaflet', {\n";
    			$output .= "center: [$longitude, $latitude],\n";
    			$output .= "zoom: $zoom\n";
			$output .= "});\n";
			$output .= "L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {\n";
			$output .= "attribution: '&copy; <a href=\"https://www.openstreetmap.org\">OpenStreetMap</a>',\n";
			$output .= "}).addTo(map);\n";
			$output .= "</script>\n";
		}

		if($name=="marker" && $shortcut)
		{
			list($longitude, $latitude, $city, $adress, $textlink, $url) = $this->yellow->toolbox->getTextArgs($text);
			if($adress) $adress = "<br>$adress"; 
			$output .= "<script type=\"text/javascript\">\n";
			$output .= "var marker = L.marker([$longitude, $latitude]).addTo(map);\n";
			$output .= "marker.bindPopup(\"<b>$city</b> $adress <br><a href='$url'>$textlink</a>\").closePopup();\n";
			$output .= "</script>\n";
		}
		return $output;
	}

	// Handle page extra HTML data
	function onExtra($name)
	{
		$output = null;
		if($name=="header")
		{
			$LeafletJs = $this->yellow->config->get("LeafletJs");
			$LeafletCss = $this->yellow->config->get("LeafletCss");
			$output .= "<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\"{$LeafletCss}leaflet.css\">\n";
			$output .= "<script type=\"text/javascript\" src=\"{$LeafletJs}leaflet.js\"></script>\n";
		}
		return $output;
	}
}

$yellow->plugins->register("leaflet", "YellowLeaflet", YellowLeaflet::VERSION);
?>